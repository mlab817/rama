<div class="small-box bg-<?php echo e($cardColor ?? 'aqua', false); ?>">
    <div class="inner">
        <h3><?php echo e($cardValue ?? 0, false); ?></h3>
        <p><?php echo e($cardTitle ?? 'Title Placeholder', false); ?></p>
    </div>
    <div class="icon">
        <i class="fa fa-<?php echo e($cardIcon ?? 'bar-chart', false); ?>"></i>
    </div>
    <a href="<?php echo e($cardAction ?? '#', false); ?>" class="small-box-footer">More info <i class="fa fa-arrow-circle-right"></i></a>
</div>
<?php /**PATH /Users/lester/Downloads/rama 2/resources/views/card.blade.php ENDPATH**/ ?>