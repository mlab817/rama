<section>
    <div class="row">
        <div class="col-md-12">
            <div class="box">
                <div class="box-header with-border">
                    <h3 class="box-title">Onboarding Timeline</h3>
                </div>

                <div class="box-body">
                    <div class="row">
                        <div class="col-md-8">
                            <p class="text-center">
                                <strong>
                                    Onboarding: <?php echo e(now()->subYear()->format('Y M'), false); ?> - <?php echo e(now()->format('Y M'), false); ?></strong>
                            </p>

                            <div class="chart">
                                <canvas id="salesChart" style="height: 100vh; width: 100vw;" height="500" width="1262"></canvas>
                            </div>

                        </div>

                        <div class="col-md-4">
                            <p class="text-center">
                                <strong>Top Five Regions</strong>
                            </p>

                            <?php $__currentLoopData = $regions->sortByDesc('vehicles_count')->slice(0, 5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $region): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="progress-group">
                                    <span class="progress-text"><?php echo e($region->name, false); ?></span>
                                    <span class="progress-number"><?php echo e($region->vehicles_count, false); ?></span>
                                    <div class="progress sm">
                                        <div class="progress-bar progress-bar-aqua" style="width: <?php echo e($region->vehicles_count / $regions->max('vehicles_count') * 100, false); ?>%"></div>
                                    </div>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>

                    </div>

                </div>

            </div>
        </div>

    </div>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script>
        const ctx = document.getElementById('salesChart').getContext('2d');

        const myChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: <?php echo json_encode($merged->keys(), 15, 512) ?>,
                datasets: [{
                    label: '# of Onboarded Vehicles',
                    data: <?php echo json_encode($merged->values(), 15, 512) ?>,
                    backgroundColor: [
                        'rgba(255, 99, 132, 0.2)',
                        'rgba(54, 162, 235, 0.2)',
                        'rgba(255, 206, 86, 0.2)',
                        'rgba(75, 192, 192, 0.2)',
                        'rgba(153, 102, 255, 0.2)',
                        'rgba(255, 159, 64, 0.2)'
                    ],
                    borderColor: [
                        'rgba(255, 99, 132, 1)',
                        'rgba(54, 162, 235, 1)',
                        'rgba(255, 206, 86, 1)',
                        'rgba(75, 192, 192, 1)',
                        'rgba(153, 102, 255, 1)',
                        'rgba(255, 159, 64, 1)'
                    ],
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    y: {
                        beginAtZero: true
                    }
                }
            }
        });
    </script>
</section>
<?php /**PATH /Users/lester/Downloads/rama 2/resources/views/dashboard/charts.blade.php ENDPATH**/ ?>