<li class="dropdown notifications-menu">
    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
        <i class="fa fa-bell-o"></i>
        <span class="label label-danger">
            <?php echo e($notifications->count(), false); ?>

        </span>
    </a>
    <ul class="dropdown-menu">
        <li class="header">You have <?php echo e($notifications->count(), false); ?> notifications</li>
        <li>

            <ul class="menu">
                <?php $__empty_1 = true; $__currentLoopData = $notifications; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $notification): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <li>
                    <?php
                        $formId = 'notification-' . $notification->id;
                    ?>
                    <form id="<?php echo e($formId, false); ?>" action="<?php echo e(route('notifications.read'), false); ?>" method="POST">
                        <?php echo csrf_field(); ?>
                        <input type="hidden" value="<?php echo e($notification->id, false); ?>" name="notification_id">
                    </form>
                    <a target="_blank" onclick="document.getElementById('<?php echo e($formId, false); ?>').submit(); return true" href="<?php echo e($notification->data['actionUrl'], false); ?>">
                        <div class="pull-left">
                            <img height="40" width="40" class="img-circle" src="https://robohash.org/<?php echo e($notification->data['from'], false); ?>?set=set3" alt="<?php echo e($notification->data['from'], false); ?>">
                        </div>
                        <h5>
                            <?php echo e($notification->data['from'], false); ?>

                            <small class="pull-right">
                                <i class="fa fa-clock-o"></i>
                                <?php echo e($notification->created_at->diffForHumans(null, null, true), false); ?>

                            </small>
                        </h5>
                        <small><?php echo e($notification->data['message'], false); ?></small>
                    </a>
                </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </ul>
        </li>
        <li class="footer"><a href="#">View all</a></li>
    </ul>
</li>
<?php /**PATH /Users/lester/Downloads/rama 2/resources/views/navbar/notifications.blade.php ENDPATH**/ ?>